# BUKO — بوكو

مشروع Flutter أولي لتطبيق سوق السيارات المستعملة في السودان، مبني من الصفر ليعمل بدون Adalo.

## التشغيل

1. ثبّت Flutter 3.24 أو أحدث.
2. افتح مجلد المشروع في Android Studio أو VS Code.
3. لأن حزمة ZIP تحتوي على كود التطبيق والموارد، أنشئ ملفات منصة Android القياسية مرة واحدة من داخل مجلد المشروع:

```bash
flutter create --platforms=android .
```

4. بعد ذلك نفّذ:

```bash
flutter pub get
flutter run
```

## إنشاء APK

```bash
flutter build apk --release
```

سيظهر الملف عادةً داخل:
`build/app/outputs/flutter-apk/app-release.apk`

## ملاحظات

- اللوقو موجود في `assets/images/buko_logo.png`.
- التطبيق RTL والعربية هي اللغة الأساسية.
- بيانات السيارات الحالية تجريبية ويمكن استبدالها بقاعدة بيانات/API لاحقًا.
- صور السيارات في النسخة التجريبية تستخدم روابط صور عامة؛ عند ربط Backend يُفضّل تخزين صور الإعلانات في خدمة صور مناسبة.
