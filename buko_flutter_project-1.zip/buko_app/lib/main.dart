import 'package:flutter/material.dart';

void main() {
  runApp(const BukoApp());
}

class BukoApp extends StatelessWidget {
  const BukoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بوكو',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        scaffoldBackgroundColor: const Color(0xFF071A2A),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF16A34A),
          brightness: Brightness.dark,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class Car {
  final String name;
  final String year;
  final String price;
  final String city;
  final String type;
  final String image;

  const Car({
    required this.name,
    required this.year,
    required this.price,
    required this.city,
    required this.type,
    required this.image,
  });
}

const cars = <Car>[
  Car(
    name: 'تويوتا هايلوكس',
    year: '2019',
    price: '85,000,000 ج.س',
    city: 'أم درمان',
    type: 'بيك أب',
    image: 'https://images.unsplash.com/photo-1553440569-bcc63803a83d?auto=format&fit=crop&w=900&q=80',
  ),
  Car(
    name: 'تويوتا برادو',
    year: '2018',
    price: '120,000,000 ج.س',
    city: 'بحري',
    type: 'دفع رباعي',
    image: 'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=900&q=80',
  ),
  Car(
    name: 'هيونداي النترا',
    year: '2021',
    price: '45,000,000 ج.س',
    city: 'الخرطوم',
    type: 'سيدان',
    image: 'https://images.unsplash.com/photo-1542282088-fe8426682b8f?auto=format&fit=crop&w=900&q=80',
  ),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selectedIndex = 0;
  final Set<int> favorites = <int>{};
  String query = '';

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homeContent(),
      FavoritesPage(favoriteCars: favorites.map((i) => cars[i]).toList()),
      const SellPage(),
      const ExplorePage(),
      const AccountPage(),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(child: pages[selectedIndex]),
        bottomNavigationBar: _bottomBar(),
      ),
    );
  }

  Widget _homeContent() {
    final filtered = cars.where((car) {
      if (query.trim().isEmpty) return true;
      final q = query.trim();
      return car.name.contains(q) || car.type.contains(q) || car.city.contains(q);
    }).toList();

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(child: _topHeader()),
        SliverToBoxAdapter(child: _hero()),
        SliverToBoxAdapter(child: _searchBox()),
        SliverToBoxAdapter(child: _advancedSearch()),
        SliverToBoxAdapter(child: _sectionTitle('تصفح حسب النوع', 'عرض الكل')),
        SliverToBoxAdapter(child: _typeChips()),
        SliverToBoxAdapter(child: _sectionTitle('السيارات المميزة', 'عرض الكل')),
        SliverToBoxAdapter(child: _carList(filtered)),
        const SliverToBoxAdapter(child: SizedBox(height: 22)),
      ],
    );
  }

  Widget _topHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
      child: Row(
        children: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none_rounded, size: 28),
          ),
          const Spacer(),
          Image.asset('assets/images/buko_logo.png', width: 92, height: 62, fit: BoxFit.contain),
          const Spacer(),
          Row(
            children: [
              const Text('السودان', style: TextStyle(fontSize: 15)),
              const SizedBox(width: 4),
              const Text('🇸🇩', style: TextStyle(fontSize: 20)),
              IconButton(onPressed: () {}, icon: const Icon(Icons.menu_rounded, size: 29)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _hero() {
    return Container(
      margin: const EdgeInsets.fromLTRB(18, 2, 18, 14),
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFF102C40), Color(0xFF061521)],
        ),
        border: Border.all(color: Colors.white.withOpacity(.08)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('السوق الأول للسيارات المستعملة في السودان', style: TextStyle(fontSize: 13, color: Colors.white70)),
          const SizedBox(height: 16),
          const Text('إبحث عن سيارتك', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const Text('بكل سهولة في السودان', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFF39C86A))),
          const SizedBox(height: 8),
          const Text('آلاف السيارات المعروضة من مختلف المدن السودانية', style: TextStyle(color: Colors.white70, height: 1.5)),
          const SizedBox(height: 18),
          Align(
            alignment: Alignment.center,
            child: Icon(Icons.directions_car_filled_rounded, size: 112, color: Colors.white.withOpacity(.92)),
          ),
        ],
      ),
    );
  }

  Widget _searchBox() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: TextField(
        onChanged: (value) => setState(() => query = value),
        textDirection: TextDirection.rtl,
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white,
          hintText: 'إبحث عن ماركة أو موديل أو كلمة مفتاحية...',
          hintStyle: const TextStyle(color: Colors.black54),
          prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFF102030), size: 31),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 18),
        ),
        style: const TextStyle(color: Colors.black87, fontSize: 15),
      ),
    );
  }

  Widget _advancedSearch() {
    return Container(
      margin: const EdgeInsets.fromLTRB(18, 14, 18, 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Column(
        children: [
          Row(
            children: [
              const Expanded(child: Text('البحث المتقدم', style: TextStyle(color: Color(0xFF138B40), fontWeight: FontWeight.bold, fontSize: 15))),
              IconButton(onPressed: _showFilters, icon: const Icon(Icons.tune_rounded, color: Color(0xFF132334))),
            ],
          ),
          Row(children: [_filterBox('الماركة', 'اختر الماركة', Icons.directions_car_outlined), const SizedBox(width: 8), _filterBox('الموديل', 'كل الموديلات', Icons.car_repair_rounded)]),
          const SizedBox(height: 8),
          Row(children: [_filterBox('السعر من', 'أي سعر', Icons.attach_money_rounded), const SizedBox(width: 8), _filterBox('السعر إلى', 'أي سعر', Icons.attach_money_rounded)]),
          const SizedBox(height: 8),
          Row(children: [_filterBox('نوع الوقود', 'الكل', Icons.local_gas_station_outlined), const SizedBox(width: 8), _filterBox('المحافظة', 'كل المحافظات', Icons.location_on_outlined)]),
          const SizedBox(height: 8),
          Row(children: [_filterBox('نوع السيارة', 'الكل', Icons.directions_car_outlined), const SizedBox(width: 8), _filterBox('ناقل الحركة', 'الكل', Icons.settings_rounded)]),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.search_rounded),
              label: const Text('بحث الآن', style: TextStyle(fontWeight: FontWeight.bold)),
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFF16A34A), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
            ),
          ),
        ],
      ),
    );
  }

  Expanded _filterBox(String title, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(border: Border.all(color: Colors.black12), borderRadius: BorderRadius.circular(13)),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFF183044), size: 23),
            const SizedBox(width: 6),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(title, style: const TextStyle(color: Colors.black54, fontSize: 11)), Text(value, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black87, fontSize: 12, fontWeight: FontWeight.w600))])),
            const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.black87),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String title, String action) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 2, 18, 8),
      child: Row(children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const Spacer(), Text(action, style: const TextStyle(color: Color(0xFF39C86A), fontWeight: FontWeight.bold))]),
    );
  }

  Widget _typeChips() {
    const types = ['أخرى', 'فان / باص', 'بيك أب', 'دفع رباعي', 'هاتشباك', 'سيدان'];
    return SizedBox(
      height: 92,
      child: ListView.separated(
        reverse: true,
        padding: const EdgeInsets.symmetric(horizontal: 18),
        scrollDirection: Axis.horizontal,
        itemCount: types.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) => Container(
          width: 82,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.directions_car_rounded, color: const Color(0xFF193047), size: 33), const SizedBox(height: 4), Text(types[i], style: const TextStyle(color: Colors.black87, fontSize: 12))]),
        ),
      ),
    );
  }

  Widget _carList(List<Car> list) {
    if (list.isEmpty) return const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('لم نجد سيارات مطابقة')));
    return SizedBox(
      height: 260,
      child: ListView.separated(
        reverse: true,
        padding: const EdgeInsets.symmetric(horizontal: 18),
        scrollDirection: Axis.horizontal,
        itemCount: list.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, i) {
          final carIndex = cars.indexOf(list[i]);
          return _carCard(list[i], carIndex);
        },
      ),
    );
  }

  Widget _carCard(Car car, int index) {
    final isFav = favorites.contains(index);
    return Container(
      width: 190,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Stack(children: [
            SizedBox(height: 115, width: double.infinity, child: Image.network(car.image, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: const Color(0xFFE9EEF2), child: const Icon(Icons.directions_car_filled_rounded, size: 65, color: Color(0xFF1B344A))))),
            Positioned(top: 8, right: 8, child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: const Color(0xFF16A34A), borderRadius: BorderRadius.circular(8)), child: const Text('مميز', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)))),
            Positioned(top: 5, left: 5, child: IconButton(onPressed: () => setState(() => isFav ? favorites.remove(index) : favorites.add(index)), icon: Icon(isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: isFav ? Colors.red : Colors.white, size: 25))),
          ]),
          Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 0), child: Text(car.name, style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.bold, fontSize: 14))),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: Text('${car.year} • ${car.type}', style: const TextStyle(color: Colors.black54, fontSize: 11))),
          Padding(padding: const EdgeInsets.fromLTRB(10, 4, 10, 0), child: Text(car.price, style: const TextStyle(color: Color(0xFF167C3C), fontWeight: FontWeight.w800, fontSize: 13))),
          Padding(padding: const EdgeInsets.fromLTRB(10, 2, 10, 7), child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [const Icon(Icons.location_on_rounded, color: Color(0xFF16A34A), size: 15), const SizedBox(width: 3), Text(car.city, style: const TextStyle(color: Colors.black54, fontSize: 11))])),
        ],
      ),
    );
  }

  Widget _bottomBar() {
    final items = [
      (Icons.home_rounded, 'الرئيسية'),
      (Icons.search_rounded, 'استكشاف'),
      (Icons.add_rounded, 'بيع سيارتك'),
      (Icons.favorite_border_rounded, 'المفضلة'),
      (Icons.person_outline_rounded, 'حسابي'),
    ];
    return Container(
      padding: const EdgeInsets.only(top: 7, bottom: 5),
      decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      child: Row(
        children: List.generate(items.length, (i) {
          final selected = selectedIndex == i;
          return Expanded(
            child: InkWell(
              onTap: () => setState(() => selectedIndex = i),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                if (i == 2) Container(width: 50, height: 50, decoration: const BoxDecoration(color: Color(0xFF16A34A), shape: BoxShape.circle), child: const Icon(Icons.add, color: Colors.white, size: 30))
                else Icon(items[i].$1, color: selected ? const Color(0xFF16A34A) : Colors.black87, size: 27),
                const SizedBox(height: 3),
                Text(items[i].$2, style: TextStyle(color: selected ? const Color(0xFF16A34A) : Colors.black87, fontSize: 11, fontWeight: selected ? FontWeight.bold : FontWeight.normal)),
              ]),
            ),
          );
        }),
      ),
    );
  }

  void _showFilters() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('الفلاتر المتقدمة', style: TextStyle(color: Colors.black87, fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            const Text('اختر الماركة والموديل والسعر والمحافظة ونوع الوقود ثم اضغط بحث.', style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 18),
            FilledButton(onPressed: () => Navigator.pop(context), style: FilledButton.styleFrom(backgroundColor: const Color(0xFF16A34A), minimumSize: const Size.fromHeight(50)), child: const Text('تطبيق الفلاتر')),
          ]),
        ),
      ),
    );
  }
}

class FavoritesPage extends StatelessWidget {
  final List<Car> favoriteCars;
  const FavoritesPage({super.key, required this.favoriteCars});
  @override
  Widget build(BuildContext context) => _simplePage('المفضلة', favoriteCars.isEmpty ? 'لم تضف سيارات للمفضلة بعد ❤️' : 'لديك ${favoriteCars.length} سيارة محفوظة');
}

class SellPage extends StatelessWidget {
  const SellPage({super.key});
  @override
  Widget build(BuildContext context) => _simplePage('بيع سيارتك', 'أضف سيارتك بسهولة ووصل إلى مشترين في السودان', button: 'إضافة إعلان');
}

class ExplorePage extends StatelessWidget {
  const ExplorePage({super.key});
  @override
  Widget build(BuildContext context) => _simplePage('استكشاف', 'ابحث عن السيارات حسب المدينة أو النوع أو السعر');
}

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});
  @override
  Widget build(BuildContext context) => _simplePage('حسابي', 'سجل الدخول لإدارة إعلاناتك ومفضلاتك');
}

Widget _simplePage(String title, String subtitle, {String? button}) {
  return Builder(builder: (context) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Container(padding: const EdgeInsets.all(28), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)), child: Column(mainAxisSize: MainAxisSize.min, children: [Image.asset('assets/images/buko_logo.png', width: 150), const SizedBox(height: 15), Text(title, style: const TextStyle(color: Colors.black87, fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, height: 1.5)), if (button != null) ...[const SizedBox(height: 20), FilledButton(onPressed: () {}, style: FilledButton.styleFrom(backgroundColor: const Color(0xFF16A34A)), child: Text(button))]]))));
}
